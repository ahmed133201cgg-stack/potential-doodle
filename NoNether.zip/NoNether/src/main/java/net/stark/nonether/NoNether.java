package net.stark.nonether;

import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPortalEvent;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.bukkit.event.world.PortalCreateEvent;
import org.bukkit.plugin.java.JavaPlugin;

public final class NoNether extends JavaPlugin implements Listener {

    private static final String BYPASS = "nonether.bypass";

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
    }

    // منع إشعال/إنشاء البوابة (فلنت، حريق، دسبنسر، إلخ) + البوابة التلقائية
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPortalCreate(PortalCreateEvent e) {
        if (e.getEntity() instanceof Player p && p.hasPermission(BYPASS)) return;

        PortalCreateEvent.CreateReason r = e.getReason();
        if (r == PortalCreateEvent.CreateReason.FIRE
                || r == PortalCreateEvent.CreateReason.NETHER_PAIR) {
            e.setCancelled(true);
            if (e.getEntity() instanceof Player p) {
                p.sendMessage(msg());
            }
        }
    }

    // منع اللاعب من الانتقال عبر بوابة النذر
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerPortal(PlayerPortalEvent e) {
        if (e.getCause() != TeleportCause.NETHER_PORTAL) return;
        if (e.getPlayer().hasPermission(BYPASS)) return;
        e.setCancelled(true);
        e.getPlayer().sendMessage(msg());
    }

    // منع الموبات والعناصر والعربات من العبور
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onEntityPortal(EntityPortalEvent e) {
        World from = e.getFrom().getWorld();
        World to = e.getTo() != null ? e.getTo().getWorld() : null;
        boolean nether = (from != null && from.getEnvironment() == World.Environment.NETHER)
                || (to != null && to.getEnvironment() == World.Environment.NETHER);
        if (nether) e.setCancelled(true);
    }

    private String msg() {
        return getConfig().getString("message", "§cبوابة النذر معطلة في هذا السيرفر.");
    }
}
